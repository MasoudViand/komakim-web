

<?php


$name =($_GET['name']);
$desc =($_GET['desc']);
$gender =$_GET['gender'];
$price =$_GET['price'];

$servername = "localhost";
$username = "root";
$password = "root";
$table='services';

try {
    $conn = new PDO("mysql:host=$servername;dbname=kamali", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  //  $sql="INSERT INTO services (name , gender, description) VALUES ('".$name.",'.$gender.','.$desc.')';
    $query = "INSERT INTO $table (name,gender,description,price) VALUES ('$name','$gender','$desc','$price')";

    echo 'سرویس با موفقیت ذخیره شد';
    $conn->query($query);
    $conn->close();
}
catch(PDOException $e)
{
    echo "Connection failed: " . $e->getMessage();
}




?>

</body>
</html>
