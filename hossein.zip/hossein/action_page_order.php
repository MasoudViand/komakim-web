

<?php


$name =($_GET['name']);
$family =($_GET['family']);
$mobile =($_GET['mobile']);
$service_id =($_GET['service_id']);
$unit_count =($_GET['unit_count']);
$address =($_GET['address']);
$desc =($_GET['desc']);
$gender =$_GET['gender'];

$servername = "localhost";
$username = "root";
$password = "root";
$orders='orders';
$users='users';

try {
    $conn = new PDO("mysql:host=$servername;dbname=kamali", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  //  $sql="INSERT INTO services (name , gender, description) VALUES ('".$name.",'.$gender.','.$desc.')';
    $query = "INSERT INTO $users(name,family,mobile,address) VALUES ('$name','$family','$mobile','$address')";


    $conn->query($query);

    $lastId =$conn->lastInsertId();
    $query = "INSERT INTO $orders(user_id,service_id,unit_count,description) VALUES ('$lastId','$service_id','$unit_count','$desc')";

    $conn->query($query);

    echo ' با موفقیت ذخیره شد';
    $conn->close();
}
catch(PDOException $e)
{
    echo "Connection failed: " . $e->getMessage();
}




?>

</body>
</html>
