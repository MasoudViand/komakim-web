<?php
$servername = "localhost";
$username = "root";
$password = "root";
$table='services';

try {
    $conn = new PDO("mysql:host=$servername;dbname=kamali", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "SELECT id, name FROM services";
    //$result = $conn->query($sql);

    $services=[];

    foreach ($conn->query($sql) as $row) {
        $service=[];

        $service['id']=$row['id'];
        $service['name']=$row['name'];
        $services[]=$service;

    }



}
catch(PDOException $e)
{
    echo "Connection failed: " . $e->getMessage();
}

//?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>سفارش</title>
</head>
<body>


<body>

<form action="action_page_order.php">
    name user <br>
    <input type="text" name="name" >

    <br>
    family user <br>
    <input type="text" name="family" >

    <br>
    تعداد
    <input type="text" name="unit_count" >

    <br>
    mobile
    <input type="text" name="mobile" >

    <br>


    address
    <input type="text" name="address" >

    <br>
    name service
    <select name="service_id" >
        <?php foreach ( $services as $service){?>
        <option value="<?php echo $service['id']?>"]><?php echo $service['name']?></option>

        <?php } ?>

    </select>
    <br><br>
    توضیحات
    <input type="text" name="desc" >
    <br><br>

    <input type="submit" value="Submit">

</form>

</body>

</body>
</html>
