<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title1</title>
</head>
<body>


<body>

<form action="action_page.php">
    service name <br>
    <input type="text" name="name" >
    <br>
    price <br>
    <input type="text" name="price" >
    <br>


    <select name="gender" class="form-control" style="width:350px">
        <option value="">--- جنسیت ---</option>
        <option value="male">مردانه</option>
        <option value="female">زنانه</option>
    </select>
    <br><br>
    توضیحات
    <input type="text" name="desc" >
    <br><br>

    <input type="submit" value="Submit">

</form>

</body>

</body>
</html>
