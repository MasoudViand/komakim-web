<?php
$servername = "localhost";
$username = "root";
$password = "root";
$table='services';

try {
    $conn = new PDO("mysql:host=$servername;dbname=kamali", $username, $password);
    // set te PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "SELECT  orders.description  as description , orders.unit_count AS unit_count, users.name as username , users.family as userfamily, users.mobile as usermobile, users.address as useraddress, services.name as servicename , services.gender as servicegender, services.price as serviceprice FROM orders INNER  JOIN services ON orders.service_id=services.id INNER JOIN users ON orders.user_id=users.id";
    //$result = $conn->query($sql);

    $services=[];

    foreach ($conn->query($sql) as $row) {
        $service=[];

        $service['description']=$row['description'];
        $service['unit_count']=$row['unit_count'];
        $service['username']=$row['username'];
        $service['userfamily']=$row['userfamily'];
        $service['usermobile']=$row['usermobile'];
        $service['useraddress']=$row['useraddress'];
        $service['servicename']=$row['servicename'];
        $service['servicegender']=$row['servicegender'];
        $service['serviceprice']=$row['serviceprice'];
       $services[]=$service;


    }




}
catch(PDOException $e)
{
    echo "Connection failed: " . $e->getMessage();
}

//?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>سفارش</title>
</head>
<body>


<body>
<table>
    <thead>
    <tr>
        <td> توضیحات</td>
        <td> تعداد</td>
        <td> نام کابر</td>
        <td> نام خانوادگی کاربر</td>
        <td> موبایل کاربر</td>
        <td> ادرس کاربر</td>
        <td> نام سرویس</td>
        <td> قیمت</td>
        <td> قیمت کل</td>

    </tr>
    </thead>

    <tbody>
    <?php foreach ($services as $service) { ?>
    <tr>
        <td> <?php echo $service['description']?></td>
        <td> <?php echo $service['unit_count']?></td>
        <td> <?php echo $service['username']?></td>
        <td> <?php echo $service['userfamily']?></td>
        <td> <?php echo $service['usermobile']?></td>
        <td> <?php echo $service['useraddress']?></td>
        <td> <?php echo $service['servicename']?></td>
        <td> <?php echo $service['serviceprice']?></td>
        <td> <?php echo $service['serviceprice']*$service['unit_count']?></td>
    </tr>
    <?php }?>

    </tbody>
</table>
</body>

</body>
</html>
