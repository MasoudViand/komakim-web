# kamaDatepicker
A jQuery based datepicker for jalali (shamsi) calendar.
