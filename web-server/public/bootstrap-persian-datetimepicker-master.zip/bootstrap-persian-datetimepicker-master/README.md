# Bootstrap 3 Persian Date/Time Picker

![DateTimePicker](http://parhood.com/usage.png)

## Submitting Issues
If you have issues, please check the following first:
- Have you read the docs?
- Do you have the latest version of momentjs?
- Do you have the latest version of jQuery?

## How to use
take a look at `usage.html` in the project directory

## Manual and the docs
documentations is same as original project:

[document and samples from Eonasdan's project](http://eonasdan.github.io/bootstrap-datetimepicker/)
